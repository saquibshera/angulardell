import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { datastruc } from './interfaces/Myemployee';
import { emp } from './interfaces/Myemployee';
@Injectable({
  providedIn: 'root'
})

export class ApiService {

  constructor(private http:HttpClient) { }
//api 
  getemployees()
  {
         return this.http.get<datastruc>("https://localhost:7194/api/Employee/GetEmployees");
  }
  Addemployee(employee:emp){

          return this.http.post("https://localhost:7194/api/Employee/Addemployee",employee)
  }
  updateemployee(id:number,employee:emp)
  {
        return this.http.put("https://localhost:7194/api/Employee/updateemployee?id="+id,employee);
  }
  deleteemployee(id:number)
  {
      return this.http.delete<string>("https://localhost:7194/api/Employee/deleteemp?id="+id);
  }
}
