export interface emp{
  id:number,
  name:string,
  address:string
}
export interface datastruc
{
status:string,
data:emp[]
}